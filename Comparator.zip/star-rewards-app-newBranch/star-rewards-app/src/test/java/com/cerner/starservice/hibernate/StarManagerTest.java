package com.cerner.starservice.hibernate;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;

import com.cerner.starservice.app.Associate;
import com.cerner.starservice.app.Star;
import com.cerner.starservice.app.StarBuilder;
import com.cerner.starservice.app.StarSummary;
import com.cerner.starservice.app.StarTeam;
import com.cerner.starservice.app.Team;

public class StarManagerTest {
	
	@BeforeClass
	public static void setUp() throws Exception {
		final String DRIVER = "org.apache.derby.jdbc.EmbeddedDriver";
		final String JDBC_URL = "jdbc:derby:sampledb;create=true";
		Class.forName(DRIVER);
		Connection connection = DriverManager.getConnection(JDBC_URL);
		connection.createStatement().execute("create table team(id varchar(15), name varchar(45), PRIMARY KEY (id))");
		connection.createStatement().execute("create table associate(id varchar(15), name varchar(45), PRIMARY KEY (id))");
		connection.createStatement().execute("create table team_associate(id integer GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1)"
				+ ", team_id varchar(15), assoc_id varchar(15), PRIMARY KEY (id),FOREIGN KEY (team_id) REFERENCES team(id),\r\n" + 
				"  FOREIGN KEY (assoc_id) REFERENCES associate(id))");
		connection.createStatement().execute("create table star(id integer GENERATED ALWAYS AS IDENTITY (START WITH 1, INCREMENT BY 1),"
				+ "assigned_by varchar(15),assigned_date TIMESTAMP,assigned_to varchar(15),comment varchar(100), PRIMARY KEY (id),\r\n" + 
				" FOREIGN KEY (assigned_by) REFERENCES associate(id),\r\n" + 
				" FOREIGN KEY (assigned_to) REFERENCES associate(id))");
		// Teams data
		connection.createStatement().execute("insert into team values('RC0321','Revenue Cycle Two')");
		connection.createStatement().execute("insert into team values('DM1045', 'Data Migration')");
		connection.createStatement().execute("insert into team values('CM0593', 'Capacity Management')");
		connection.createStatement().execute("insert into team values('ST7687', 'Sample Team')");
		connection.createStatement().execute("insert into team values('SG0985', 'Single Team')");
		// Associates data
		connection.createStatement().execute("insert into associate values('MA065203', 'Blake')");
		connection.createStatement().execute("insert into associate values('KD055198', 'John')");
		connection.createStatement().execute("insert into associate values('MK051308', 'Amber')");
		connection.createStatement().execute("insert into associate values('KY055456', 'Amanda')");
		connection.createStatement().execute("insert into associate values('SG065109', 'Chris')");
		connection.createStatement().execute("insert into associate values('SC984753', 'Robert')");
		connection.createStatement().execute("insert into associate values('FG093845', 'Fksjdhf')");
		connection.createStatement().execute("insert into associate values('TO902384', 'TjbfObksdjf')");
		connection.createStatement().execute("insert into associate values('RQ938454', 'RldjksQ;skdjf')");
		connection.createStatement().execute("insert into associate values('TN034588', 'TkjsdhfNfksdh')");
		connection.createStatement().execute("insert into associate values('OZ193720', 'treioiou')");
		connection.createStatement().execute("insert into associate values('TR562308', 'guiiiidsa')");
		connection.createStatement().execute("insert into associate values('ZD039485', 'Single')");
		// Team_Associate data
		connection.createStatement().execute("insert into team_associate(team_id,assoc_id) values('RC0321','MA065203')");
		connection.createStatement().execute("insert into team_associate(team_id,assoc_id) values('RC0321','KD055198')");
		connection.createStatement().execute("insert into team_associate(team_id,assoc_id) values('RC0321','MK051308')");
		connection.createStatement().execute("insert into team_associate(team_id,assoc_id) values('DM1045','KY055456')");
		connection.createStatement().execute("insert into team_associate(team_id,assoc_id) values('DM1045','SG065109')");
		connection.createStatement().execute("insert into team_associate(team_id,assoc_id) values('DM1045','SC984753')");
		connection.createStatement().execute("insert into team_associate(team_id,assoc_id) values('CM0593','FG093845')");
		connection.createStatement().execute("insert into team_associate(team_id,assoc_id) values('CM0593','TO902384')");
		connection.createStatement().execute("insert into team_associate(team_id,assoc_id) values('CM0593','RQ938454')");
		connection.createStatement().execute("insert into team_associate(team_id,assoc_id) values('CM0593','TN034588')");
		connection.createStatement().execute("insert into team_associate(team_id,assoc_id) values('ST7687','OZ193720')");
		connection.createStatement().execute("insert into team_associate(team_id,assoc_id) values('ST7687','TR562308')");
		connection.createStatement().execute("insert into team_associate(team_id,assoc_id) values('SG0985','ZD039485')");
		//Star data
		connection.createStatement().execute("insert into star(assigned_by,assigned_date,assigned_to,comment) values('MA065203','2018-12-31 00:00:00','SG065109','One')");
		connection.createStatement().execute("insert into star(assigned_by,assigned_date,assigned_to,comment) values('MK051308','2018-12-31 00:00:00','TO902384','Two')");
		connection.createStatement().execute("insert into star(assigned_by,assigned_date,assigned_to,comment) values('TO902384','2018-12-31 00:00:00','FG093845','Three')");
		connection.createStatement().execute("insert into star(assigned_by,assigned_date,assigned_to,comment) values('RQ938454','2018-12-31 00:00:00','FG093845','Four')");
		connection.createStatement().execute("insert into star(assigned_by,assigned_date,assigned_to,comment) values('KY055456','2018-12-31 00:00:00','SC984753','Five')");
		connection.createStatement().execute("insert into star(assigned_by,assigned_date,assigned_to,comment) values('KD055198','2018-12-31 00:00:00','MA065203','Six')");
		connection.createStatement().execute("insert into star(assigned_by,assigned_date,assigned_to,comment) values('TN034588','2018-12-31 00:00:00','RQ938454','Seven')");
		connection.createStatement().execute("insert into star(assigned_by,assigned_date,assigned_to,comment) values('TN034588','2018-12-31 00:00:00','MA065203','Eight')");
		connection.createStatement().execute("insert into star(assigned_by,assigned_date,assigned_to,comment) values('KD055198','2018-12-31 00:00:00','RQ938454','Nine')");
		connection.close();
	}
	
	@AfterClass
	public static void tearDown() throws Exception {
		final String DRIVER = "org.apache.derby.jdbc.EmbeddedDriver";
		final String JDBC_URL = "jdbc:derby:sampledb;create=true";
		Class.forName(DRIVER);
		Connection connection = DriverManager.getConnection(JDBC_URL);
		connection.createStatement().execute("drop table star");
		connection.createStatement().execute("drop table team_associate");
		connection.createStatement().execute("drop table team");
		connection.createStatement().execute("drop table associate");
		connection.close();
	}
	
	@Rule
	public ExpectedException thrown = ExpectedException.none();
	
	@Test
	public void addTeam_validTeam() throws ClassNotFoundException, SQLException {
		String expected = null,actual;
		final String DRIVER = "org.apache.derby.jdbc.EmbeddedDriver";
		final String JDBC_URL = "jdbc:derby:sampledb;create=true";
		Class.forName(DRIVER);
		Connection connection = DriverManager.getConnection(JDBC_URL);
		StarManager manager = new StarManager();
		Team team = new Team();
		team.setTeam_id("RC13238");
		team.setTeam_name("Valid Team Test");
		assertTrue(manager.addTeam(team));
		expected = "Valid Team Test";
		ResultSet rs = connection.createStatement().executeQuery("select name from team where id='RC13238'");
		rs.next();
		actual = rs.getString(1);
		assertEquals(expected,actual);
		connection.close();
	}
	
	@Test
	public void addTeam_duplicateTeamId() {
		StarManager manager = new StarManager();
		Team team = new Team();
		team.setTeam_id("RC13238");
		team.setTeam_name("Duplicate TeamId Test");
		assertFalse(manager.addTeam(team));
	}
	
	@Test
	public void addAssociate_validAssociate() throws ClassNotFoundException, SQLException {
		String expected = null,actual;
		final String DRIVER = "org.apache.derby.jdbc.EmbeddedDriver";
		final String JDBC_URL = "jdbc:derby:sampledb;create=true";
		Class.forName(DRIVER);
		Connection connection = DriverManager.getConnection(JDBC_URL);
		StarManager manager = new StarManager();
		Team team = new Team();
		team.setTeam_id("DM1045");
		Associate associate = new Associate();
		associate.setId("MA065202");
		associate.setName("Mani Kanta");
		associate.setTeam(team);
		assertTrue(manager.addAssociate(associate));
		expected = "Mani Kanta";
		ResultSet rs = connection.createStatement().executeQuery("select name from associate where id='MA065202'");
		rs.next();
		actual = rs.getString(1);
		assertEquals(expected,actual);
		connection.close();
	}
	
	@Test
	public void addAssociate_duplicateAssociateId() {
		StarManager manager = new StarManager();
		Team team = new Team();
		team.setTeam_id("DM1045");
		Associate associate = new Associate();
		associate.setId("MA065202");
		associate.setName("Lohith");
		associate.setTeam(team);
		assertFalse(manager.addAssociate(associate));
	}
	
	@Test
	public void addAssociate_teamDoesNotExist(){
		StarManager manager = new StarManager();
		Team team = new Team();
		team.setTeam_id("XZ45687");
		Associate associate = new Associate();
		associate.setId("MA691456");
		associate.setName("ASDFJKL");
		associate.setTeam(team);
		assertFalse(manager.addAssociate(associate));
	}
	
	@Test
	public void getTeamMembers_validAssociate() {
		String expectedTeamId = "CM0593";
		StarManager manager = new StarManager();
		List<Associate> result = manager.getTeamMembers("FG093845");
		Iterator<Associate> iterator = result.iterator();
		while(iterator.hasNext()) {
			assertEquals(expectedTeamId,iterator.next().getTeam().getTeam_id());
		}
	}
	
	@Test
	public void getTeamMembers_invalidAssociate(){
		StarManager manager = new StarManager();
		assertEquals(null,manager.getTeamMembers("XY045986"));
	}
	
	@Test
	public void getTeamMembers_invalidTeam() {
		StarManager manager = new StarManager();
		assertTrue(manager.getTeamMembers("ZD039485").isEmpty());
	}
	
	@Test
	public void giveStar_validStar() throws ClassNotFoundException, SQLException {
		String expected = null,actual;
		ResultSet rs;
		final String DRIVER = "org.apache.derby.jdbc.EmbeddedDriver";
		final String JDBC_URL = "jdbc:derby:sampledb;create=true";
		Class.forName(DRIVER);
		Connection connection = DriverManager.getConnection(JDBC_URL);
		Associate assignedBy = new Associate();
		assignedBy.setId("SC984753");
		Associate assignedTo = new Associate();
		assignedTo.setId("TN034588");
		Star star = new StarBuilder()
				.setAssignedBy(assignedBy)
				.setAssignedTo(assignedTo)
				.setComment("Valid Star")
				.getStar();
		StarManager manager = new StarManager();
		assertTrue(manager.giveStar(star));
		expected = "Valid Star";
		rs = connection.createStatement().executeQuery("select comment from star where assigned_by='SC984753' "
				+ "and assigned_to='TN034588' and assigned_date between TIMESTAMP('2018-12-31 00:00:00') and TIMESTAMP('2019-01-04 23:59:00')");
		rs.next();
		actual = rs.getString(1);
		assertEquals(expected,actual);
		connection.close();
	}
	
	@Test
	public void giveStar_validStarSecondTimeToSameAssociate() {
		thrown.expect(IllegalArgumentException.class);
		thrown.expectMessage("Cannot give multiple stars to same Associate in a week");
		Associate assignedBy = new Associate();
		assignedBy.setId("KD055198");
		Associate assignedTo = new Associate();
		assignedTo.setId("MA065203");
		Star star = new StarBuilder()
				.setAssignedBy(assignedBy)
				.setAssignedTo(assignedTo)
				.setComment("Invalid Star Second Time to same employee")
				.getStar();
		StarManager manager = new StarManager();
		manager.giveStar(star);
	}
	
	@Test
	public void giveStar_associateToDoesNotExist() {
		Associate assignedBy = new Associate();
		assignedBy.setId("TN034588");
		Associate assignedTo = new Associate();
		assignedTo.setId("RL045673");
		Star star = new StarBuilder()
				.setAssignedBy(assignedBy)
				.setAssignedTo(assignedTo)
				.setComment("Valid Star")
				.getStar();
		StarManager manager = new StarManager();
		assertFalse(manager.giveStar(star));
	}
	
	@SuppressWarnings("unused")
	@Test
	public void giveStar_addStarToSelf() {
		thrown.expect(IllegalArgumentException.class);
		thrown.expectMessage("One cannot assign a star to self");
		Associate assignedBy = new Associate();
		assignedBy.setId("MA065202");
		Associate assignedTo = new Associate();
		assignedTo.setId("MA065202");
		Star star = new StarBuilder()
				.setAssignedBy(assignedBy)
				.setAssignedTo(assignedTo)
				.setComment("Invalid Star")
				.getStar();
	}
	
	@SuppressWarnings("unused")
	@Test
	public void giveStar_withoutComment() {
		thrown.expect(IllegalArgumentException.class);
		thrown.expectMessage("Cannot give a star without a comment");
		Associate assignedBy = new Associate();
		assignedBy.setId("MA065202");
		Associate assignedTo = new Associate();
		assignedTo.setId("KY055456");
		Star star = new StarBuilder()
				.setAssignedBy(assignedBy)
				.setAssignedTo(assignedTo)
				.getStar();
	}
	
	@SuppressWarnings("unused")
	@Test
	public void giveStar_withoutAssignedBy() {
		thrown.expect(IllegalArgumentException.class);
		thrown.expectMessage("AssignedBy cannot be empty");
		Associate assignedBy = new Associate();
		assignedBy.setId("MA065202");
		Associate assignedTo = new Associate();
		assignedTo.setId("KY055456");
		Star star = new StarBuilder()
				.setAssignedTo(assignedTo)
				.setComment("Invalid Star")
				.getStar();
	}
	
	@SuppressWarnings("unused")
	@Test
	public void giveStar_withoutAssignedTo() {
		thrown.expect(IllegalArgumentException.class);
		thrown.expectMessage("AssignedTo cannot be empty");
		Associate assignedBy = new Associate();
		assignedBy.setId("MA065202");
		Associate assignedTo = new Associate();
		assignedTo.setId("KY055456");
		Star star = new StarBuilder()
				.setAssignedBy(assignedBy)
				.setComment("Invalid Star")
				.getStar();
	}

	@Test
	public void removeStar_starExist() throws ClassNotFoundException, SQLException {
		String expected=null,actual;
		ResultSet rs;
		final String DRIVER = "org.apache.derby.jdbc.EmbeddedDriver";
		final String JDBC_URL = "jdbc:derby:sampledb;create=true";
		Class.forName(DRIVER);
		Connection connection = DriverManager.getConnection(JDBC_URL);
		Associate assignedBy = new Associate();
		assignedBy.setId("KY055456");
		Associate assignedTo = new Associate();
		assignedTo.setId("SC984753");
		StarManager manager = new StarManager();
		expected = "Five";
		rs = connection.createStatement().executeQuery("select comment from star where assigned_by='KY055456' "
				+ "and assigned_to='SC984753' and assigned_date between TIMESTAMP('2018-12-31 00:00:00') and TIMESTAMP('2019-01-04 23:59:00')");
		rs.next();
		actual = rs.getString(1);
		assertEquals(expected,actual);
		manager.removeStar(assignedBy, assignedTo);
		rs = connection.createStatement().executeQuery("select comment from star where assigned_by='KY055456' "
				+ "and assigned_to='SC984753' and assigned_date between TIMESTAMP('2018-12-31 00:00:00') and TIMESTAMP('2019-01-04 23:59:00')");
		assertFalse(rs.next());
		connection.close();	
	}
	
	@Test
	public void removeStar_starDoesNotExist() {
		thrown.expect(IllegalArgumentException.class);
		thrown.expectMessage("Could not find a star");
		Associate assignedBy = new Associate();
		assignedBy.setId("TO902387");
		Associate assignedTo = new Associate();
		assignedTo.setId("MK051308");
		StarManager manager = new StarManager();
		manager.removeStar(assignedBy, assignedTo);
	}

	@Test
	public void getWinner_starDataForTeamExist() {
		List<String> expected = new ArrayList<String>();
		List<String> actual = new ArrayList<String>();
		expected.add("FG093845");
		expected.add("RQ938454");
		StarManager manager = new StarManager();
		Team team = new Team();
		team.setTeam_id("CM0593");
		actual = manager.getWinner(team);
		assertTrue(actual.containsAll(expected));
	}
	
	@Test
	public void getWinner_starDataForTeamDoesNotExist() {
		thrown.expect(IllegalArgumentException.class);
		thrown.expectMessage("Team does not exist or team didn't participated in current star week");
		StarManager manager = new StarManager();
		Team team = new Team();
		team.setTeam_id("ST7687");
		manager.getWinner(team);
	}
	
	@Test
	public void getWinner_teamDoesNotExist() {
		thrown.expect(IllegalArgumentException.class);
		thrown.expectMessage("Team does not exist or team didn't participated in current star week");
		StarManager manager = new StarManager();
		Team team = new Team();
		team.setTeam_id("CM059334");
		manager.getWinner(team);
	}
	
	@Test
	public void testGetStarAssociates_teamDoesNotExist() {
		thrown.expect(IllegalArgumentException.class);
		thrown.expectMessage("Team does not exist");
		StarManager manager = new StarManager();
		manager.getStarAssociates("CM059332232");
	}

	@Test
	public void testGetStarAssociates_teamWithoutStarMembers() {
		StarManager manager = new StarManager();
		StarTeam team = manager.getStarAssociates("ST7687");
		String teamNameActual = team.getTeamName();
		String teamNameExpected = "Sample Team";
		List<StarSummary> membersActual = team.getMembers();
		assertEquals(teamNameExpected, teamNameActual);
		assertNull(membersActual);
	}

	@Test
	public void testGetStarAssociates_teamExists() {
		StarManager manager = new StarManager();
		StarTeam teamStar = manager.getStarAssociates("RC0321");
		String teamNameExpected = "Revenue Cycle Two";
		String assignedToIdExpected = "MA065203";
		String assignedToNameExpected = "Blake";
		List<StarSummary> listStarSummary = teamStar.getMembers();
		Map<String, String> actualSubTree1 = listStarSummary.get(0).getStars().get(0);
		Map<String, String> actualSubTree2 = listStarSummary.get(0).getStars().get(1);
		Map<String, String> expectedHashMap1 = new LinkedHashMap<String, String>();
		expectedHashMap1.put("assignedById", "KD055198");
		expectedHashMap1.put("assignedByName", "John");
		expectedHashMap1.put("comment", "Six");
		Map<String, String> expectedHashMap2 = new LinkedHashMap<String, String>();
		expectedHashMap2.put("assignedById", "TN034588");
		expectedHashMap2.put("assignedByName", "TkjsdhfNfksdh");
		expectedHashMap2.put("comment", "Eight");
		assertEquals(teamNameExpected, teamStar.getTeamName());
		assertEquals(assignedToIdExpected, listStarSummary.get(0).getAssignedToId());
		assertEquals(assignedToNameExpected, listStarSummary.get(0).getAssignedToName());
		assertEquals(expectedHashMap1, actualSubTree1);
		assertEquals(expectedHashMap2, actualSubTree2);
	}
}