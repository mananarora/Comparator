package com.cerner.starservice.hibernate;

import java.sql.Timestamp;
import java.time.DateTimeException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.persistence.PersistenceException;
import javax.persistence.RollbackException;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Root;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

import com.cerner.starservice.app.Associate;
import com.cerner.starservice.app.Star;
import com.cerner.starservice.app.StarManagerIface;
import com.cerner.starservice.app.StarSummary;
import com.cerner.starservice.app.StarTeam;
import com.cerner.starservice.app.Team;

/**
 * Manager class which helps in <br />
 * 1. Adding a team <br />
 * 2. Adding an associate <br />
 * 3. Giving a star to an associate <br />
 * 4. Remove star assigned to an associate in the current week <br />
 * 5. Get winner for the current week <br /> 
 * 
 * @author MA065202
 * @version 1.1
 * @since 28th October 2018
 */
public class StarManager implements StarManagerIface {
	private SessionFactory sessionFactory;
	private Session session;
	private Transaction transaction;
	
	/**
	 * StarManager constructor which in turn calls overloaded constructor StarManager(SessionFactory).
	 */
	public StarManager() {
		this(HibernateUtil.getSessionFactory());
	}

	StarManager(SessionFactory sessionFactory){
		this.sessionFactory = sessionFactory;
		try {
			this.session = this.sessionFactory.getCurrentSession();
		}catch(HibernateException he) {
			he.printStackTrace();
		}
	}
	
	private void beginTransaction() {
		try {
			transaction = session.beginTransaction();
		}catch(HibernateException he) {
			closeSession();
			he.printStackTrace();
		}
	}
	
	private boolean commitTransaction() {
		try {
			transaction.commit();
			closeSession();
			return true;
		}catch(IllegalStateException ise) {
			ise.printStackTrace();
			closeSession();
			return false;
		}catch(RollbackException re) {
			re.printStackTrace();
			closeSession();
			return false;
		}catch(PersistenceException pe) {
			pe.printStackTrace();
			closeSession();
			return false;
		}
	}
	
	private Date getMondayOfTheWeek() throws DateTimeException{
		Date monday = null;
		Calendar today = Calendar.getInstance();
		int difference;
	    int day = today.get(Calendar.DAY_OF_WEEK);
	    if(!(day >= Calendar.MONDAY && day <= Calendar.FRIDAY)) {
	    	closeSession();
	    	throw new DateTimeException("Star reporting for this week has been closed");
	    }
	    else {
	    	difference = day - Calendar.MONDAY;
	    	today.add(Calendar.DAY_OF_WEEK, -difference);
		    today.set(Calendar.HOUR_OF_DAY, 0);
		    today.set(Calendar.MINUTE, 0);
		    today.set(Calendar.MILLISECOND, 0);
		    today.set(Calendar.SECOND, 0);
		    monday = today.getTime();
	    	return monday;
	    }
	}
	
	private Date getFridayOfTheWeek() throws DateTimeException{
		Date friday = null;
		Calendar today = Calendar.getInstance();
		int difference;
	    int day = today.get(Calendar.DAY_OF_WEEK);
	    if(!(day >= Calendar.MONDAY && day <= Calendar.FRIDAY)) {
	    	closeSession();
	    	throw new DateTimeException("Star reporting for this week has been closed");
	    }
	    else{
	        difference = Calendar.FRIDAY - day;   
		    today = Calendar.getInstance();
		    today.add(Calendar.DAY_OF_WEEK, difference);
		    friday = today.getTime();
		    return friday;
		}
	}

	@SuppressWarnings({ "unchecked"})
	private boolean isSecondEntry(Associate assignedBy, Associate assignedTo ){
	    beginTransaction();
	    String hqlQuery = "FROM Star s where s.assignedDate between :monday and :friday and s.assignedBy=:assignedBy"
	    		+ " and s.assignedTo=:assignedTo";
		List<Star> resultStar = session.createQuery(hqlQuery)
				.setParameter("assignedTo", assignedTo)
	    		.setParameter("assignedBy", assignedBy)	    		
	    		.setParameter("monday", getMondayOfTheWeek())
	    		.setParameter("friday", getFridayOfTheWeek())
	    		.getResultList();
	    if(!resultStar.isEmpty()) return true;
	    return false;
	}
	
	/**
	 * Method to add a team.
	 * @param team - instance of Team.class
	 * @return boolean
	 */
	public boolean addTeam(Team team) throws IllegalArgumentException {
		try {
			beginTransaction();
			session.save(team);
			return commitTransaction();
		}catch(HibernateException he){
			closeSession();
			throw he;
		}
	}
	
	/**
	 * Method to add an Associate.
	 * @param associate - instance of Associate.class
	 * @return boolean
	 */
	public boolean addAssociate(Associate associate) throws IllegalArgumentException{
		try {
			beginTransaction();
			session.save(associate);
			return commitTransaction();
		}catch(HibernateException he) {
			closeSession();
			throw he;
		}
	}
	
	/**
	 * Get team members based on associate id.
	 * @param associateId - ID of an Associate.
	 * @return List<Associate>
	 */
	@SuppressWarnings("unchecked")
	public List<Associate> getTeamMembers(String associateId) throws IllegalArgumentException{
		List<Associate> result = null;
		try {
			beginTransaction();
			Associate associate = session.find(Associate.class, associateId);
			if(associate == null) {
				commitTransaction();
				return result;
			} 
			String hql = "From Associate a where a.team=:team and a.id!=:id";
			result= session.createQuery(hql)
		    		.setParameter("team", associate.getTeam())
		    		.setParameter("id", associate.getId())
		    		.getResultList();
			commitTransaction();
			return result;
		}catch(HibernateException he) {
			closeSession();
			throw he;
		}
	}
	
	/**
	 * Method to give a star to an employee.
	 * @param star - instance of Star class
	 * @return boolean
	 */
	public boolean giveStar(Star star) throws IllegalArgumentException {
		star.setAssignedDate(new Timestamp(new Date().getTime()));
		try{
			if(isSecondEntry(star.getAssignedBy(),star.getAssignedTo()))
				throw new IllegalArgumentException("Cannot give multiple stars to same Associate in a week");
			else {
				session.save(star);
				return commitTransaction();
			}
		}catch(IllegalArgumentException ie) {
			closeSession();
			throw ie;
		}catch(HibernateException he) {
			closeSession();
			throw he;
		}
	}

	/**
	 * Method to remove a given star in the current week.
	 * @param assignedBy,assignedTo - both are instances of Associate class
	 */
	@SuppressWarnings({ "unchecked"})
	public boolean removeStar(Associate assignedBy, Associate assignedTo) throws IllegalArgumentException {
	   try {
	    	beginTransaction();
	    	String removeHql = "FROM Star s where s.assignedDate between :monday and :friday and s.assignedBy=:assignedBy"
			    		+ " and s.assignedTo=:assignedTo";
			    List<Star> resultStar= session.createQuery(removeHql)
			    		.setParameter("assignedBy", assignedBy)
			    		.setParameter("assignedTo", assignedTo)
			    		.setParameter("monday", getMondayOfTheWeek())
			    		.setParameter("friday", getFridayOfTheWeek())
			    		.getResultList();
		    if(resultStar.isEmpty()) throw new IllegalArgumentException("Could not find a star");
		    else {
				Iterator<Star> starIterator = resultStar.iterator();
				while(starIterator.hasNext()) {
					session.delete(starIterator.next());
				}
				return commitTransaction();
			}
		}catch(IllegalArgumentException iae) {
			closeSession();
			throw iae;
		}catch(HibernateException he) {
			closeSession();
			throw he;
		}
	}
	
	/**
	 * Get list of current week winners.
	 * @param team - instance of Team class.
	 * @return list of winner associate id.
	 */
	@SuppressWarnings({ "rawtypes" })
	public List<String> getWinner(Team team) throws IllegalArgumentException{
		List<String> associateIds=new ArrayList<String>();
		try {
    	    String winnerHql = "select max(a.name),max(s.assignedTo),max(t.id),count(*) as star_count from Star s inner join s.assignedTo a inner join "
		    		+ "a.team t where s.assignedDate between :monday and :friday and t.team_id = :teamId "
		    		+ "group by s.assignedTo order by star_count DESC";
		    beginTransaction();
		    List result = session.createQuery(winnerHql)
		    		.setParameter("friday", getFridayOfTheWeek())
		    		.setParameter("monday", getMondayOfTheWeek())
		    		.setParameter("teamId", team.getTeam_id())
		    		.getResultList();
		    commitTransaction();
		    Iterator iterator = result.iterator();
		    if(result.isEmpty())
		    	throw new IllegalArgumentException("Team does not exist or team didn't participated in current star week");
		    else {
		    	Long winnerStarCount;
				Long currentStarCount;
		    	Object resultOb[] = (Object[])iterator.next();
		    	currentStarCount = winnerStarCount = (Long) resultOb[3];
		    	associateIds.add(((Associate)resultOb[1]).getId());
		    	while(iterator.hasNext()) {
		    		Object resultOb1[] = (Object[])iterator.next();
		    		currentStarCount = (Long) resultOb1[3];
			    	if(currentStarCount != winnerStarCount) {
			    		break;
			    	}
			    	associateIds.add(((Associate)resultOb1[1]).getId());
			    }
		    	return associateIds;
		    }
	    }catch(IllegalArgumentException iae){
	    	closeSession();
	    	throw iae;
	    }catch(HibernateException he) {
			closeSession();
			throw he;
		}
	}
	
	/**
	 * Method to close dangling connections. Helps in resource utilization.
	 */
	private void closeSession(){
		try {
			session.close();
			sessionFactory.close();
		}catch(HibernateException he) {
			he.printStackTrace();
		}
	}
	
	/**
	 * Get list of current week star associates.
	 * @param teamId - id of Team.
	 * @return instance of StarTeam class.
	 */
	public StarTeam getStarAssociates(String teamId) {
		StarTeam team = new StarTeam();
		List<Star> starList = null;
		String teamName = null;
		List<StarSummary> detailsOfStarAssociates = new ArrayList<StarSummary>();
		try {
			beginTransaction();
			CriteriaBuilder criteriaBuilder = session.getCriteriaBuilder();
			teamName = getTeamName(criteriaBuilder, teamId);
			if (teamName != null) {
				team.setTeamName(teamName);
				CriteriaQuery<Star> criteriaQuery = criteriaBuilder.createQuery(Star.class);
				Root<Star> root = criteriaQuery.from(Star.class);
				Join<Star, Associate> join = root.join("assignedTo").join("team");
				criteriaQuery.select(root).where(criteriaBuilder.equal(join.get("team_id"), teamId),
						criteriaBuilder.greaterThanOrEqualTo(root.<Date>get("assignedDate"), getMondayOfTheWeek()),
						criteriaBuilder.lessThanOrEqualTo(root.<Date>get("assignedDate"), getFridayOfTheWeek()));
				criteriaQuery.select(root);
				Query<Star> query = session.createQuery(criteriaQuery);
				starList = query.getResultList();
				Map<String, Integer> countOfAssignedTo = new HashMap<String, Integer>();
				for (Star star : starList) {
					if (countOfAssignedTo.get(star.getAssignedTo().getId()) != null) {
						int count = countOfAssignedTo.get(star.getAssignedTo().getId());
						countOfAssignedTo.put(star.getAssignedTo().getId(), ++count);
					} else {
						countOfAssignedTo.put(star.getAssignedTo().getId(), 1);
					}
				}
				CompareByNameComparator compareByNameComparator = new CompareByNameComparator();
				Collections.sort(starList, compareByNameComparator);
				CompareByCountComparator compareByCountComparator = new CompareByCountComparator(countOfAssignedTo);
				Collections.sort(starList, compareByCountComparator);
				session.close();
			} else {
				throw new IllegalArgumentException("Team does not exist");
			}
		} catch (IllegalArgumentException iae) {
			closeSession();
			throw iae;
		} catch (IllegalStateException ise) {
			closeSession();
			throw ise;
		} catch (NullPointerException npe) {
			closeSession();
			throw npe;
		} catch (ClassCastException cce) {
			closeSession();
			throw cce;
		}
		if (starList.isEmpty() || starList == null) {
			return team;
		} else {
			String prevAssignedTo = null;
			int index = 0;
			teamName = starList.get(index).getAssignedTo().getTeam().getTeam_name();
			for (Star star : starList) {
				StarSummary starMembers = new StarSummary();
				LinkedHashMap<String, String> setAssignedByAndComment = new LinkedHashMap<String, String>();
				List<LinkedHashMap<String, String>> listToStoreAssignedByAndComment = new ArrayList<LinkedHashMap<String, String>>();
				if (!star.getAssignedTo().getId().equals(prevAssignedTo)) {
					starMembers.setAssignedToId(star.getAssignedTo().getId());
					starMembers.setAssignedToName(star.getAssignedTo().getName());
					setAssignedByAndComment.put("assignedById", star.getAssignedBy().getId());
					setAssignedByAndComment.put("assignedByName", star.getAssignedBy().getName());
					setAssignedByAndComment.put("comment", star.getComment());
					listToStoreAssignedByAndComment.add(setAssignedByAndComment);
					starMembers.setStars(listToStoreAssignedByAndComment);
					prevAssignedTo = star.getAssignedTo().getId();
					detailsOfStarAssociates.add(starMembers);
					index++;
				} else {
					setAssignedByAndComment.put("assignedById", star.getAssignedBy().getId());
					setAssignedByAndComment.put("assignedByName", star.getAssignedBy().getName());
					setAssignedByAndComment.put("comment", star.getComment());
					detailsOfStarAssociates.get(index - 1).getStars().add(setAssignedByAndComment);
				}
			}
		}
		team.setMembers(detailsOfStarAssociates);
		return team;
	}
	
	/**
	 * Method to get name of the team.
	 * @param teamId - id of Team
	 * @return String
	 */
	private String getTeamName(CriteriaBuilder builder, String teamId) {
		CriteriaQuery<Team> criteriaQueryTeam = builder.createQuery(Team.class);
		Root<Team> rootTeam = criteriaQueryTeam.from(Team.class);
		criteriaQueryTeam.where(builder.equal(rootTeam.get("team_id"), teamId));
		Query<Team> queryTeam = session.createQuery(criteriaQueryTeam);
		Team listTeam = queryTeam.uniqueResult();
		return (listTeam != null) ? listTeam.getTeam_name() : null;
	}
}