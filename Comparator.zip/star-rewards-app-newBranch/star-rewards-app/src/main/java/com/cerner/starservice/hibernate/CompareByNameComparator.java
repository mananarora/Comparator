package com.cerner.starservice.hibernate;

import java.util.Comparator;

import com.cerner.starservice.app.Star;

public class CompareByNameComparator implements Comparator<Star> {

	/**
	 * @param first, second object which are to be compared on basis of their name.
	 * @return int.
	 */
	public int compare(Star first, Star second) {
		return (second.getAssignedTo().getId()).compareTo(first.getAssignedTo().getId());
	}
}
