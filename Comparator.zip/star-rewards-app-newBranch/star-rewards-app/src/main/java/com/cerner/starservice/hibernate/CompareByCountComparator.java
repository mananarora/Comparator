package com.cerner.starservice.hibernate;

import java.util.Comparator;
import java.util.Map;

import com.cerner.starservice.app.Star;

public class CompareByCountComparator implements Comparator<Star> {
	Map<String, Integer> countDetails;
	
	/**
	 * @param countDetails to set count.
	 */
	public CompareByCountComparator(Map<String, Integer> countDetails) {
		this.countDetails = countDetails;
	}
	/**
	 * @param first, second object which are to be compared on basis of their count.
	 * @return int.
	 */
	public int compare(Star first, Star second) {
		return (countDetails.get(second.getAssignedTo().getId())) - countDetails.get(first.getAssignedTo().getId());
	}
}
