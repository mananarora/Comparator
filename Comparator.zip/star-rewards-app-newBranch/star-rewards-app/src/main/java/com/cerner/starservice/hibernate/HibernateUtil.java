package com.cerner.starservice.hibernate;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.cerner.starservice.app.Associate;
import com.cerner.starservice.app.Star;
import com.cerner.starservice.app.Team;

/**
 * Singleton Utility class to provide SessionFactory 
 * @author MA065202
 * @version 1.0
 * @since 10 October 2018 
 */
public class HibernateUtil {
	
	private static SessionFactory sessionFactory;
	private HibernateUtil(){}
	/**
	 * returns an object of SessionFactory loaded using hibernate.cfg.xml
	 */
	public static final SessionFactory getSessionFactory()  
    {  
        if ( sessionFactory == null || sessionFactory.isClosed())  {
            synchronized (HibernateUtil.class) {
                if (sessionFactory == null || sessionFactory.isClosed()) {
                	try {
                		sessionFactory = new Configuration()
            					.configure("hibernate.cfg.xml")
            					.addAnnotatedClass(Star.class)
            					.addAnnotatedClass(Associate.class)
            					.addAnnotatedClass(Team.class)
            					.buildSessionFactory();	
            					return sessionFactory;
            		}catch(Throwable ex) {
            			System.err.println("Initial SessionFactory creation failed." + ex);
                        ex.printStackTrace();
                        throw new ExceptionInInitializerError(ex);
            		}
                }
            }
        } 
        return sessionFactory; 
    }
}
